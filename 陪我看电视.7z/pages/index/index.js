//index.js
//获取应用实例
const app = getApp()

Page({
  
  goToCCTV1:function(param){
    wx.navigateTo({
      url: 'CCTV-1',
    })
  },  
  goToCCTV3: function(param) {
    wx.navigateTo({
      url: 'CCTV-3',
    })
  },
  goToCCTV4: function (param) {
    wx.navigateTo({
      url: 'CCTV-4',
    })
  },  
  goToCCTV5: function (param) {
    wx.navigateTo({
      url: 'CCTV-5',
    })
  },  
  goToCCTV6: function (param) {
    wx.navigateTo({
      url: 'CCTV-6',
    })
  },  
  goToCCTV9: function (param) {
    wx.navigateTo({
      url: 'CCTV-9',
    })
  },  
  goToCCTV10: function (param) {
    wx.navigateTo({
      url: 'CCTV-10',
    })
  },  
  goToCCTV12: function (param) {
    wx.navigateTo({
      url: 'CCTV-12',
    })
  },  
  goToCCTV13: function (param) {
    wx.navigateTo({
      url: 'CCTV-13',
    })
  },  
  goToCCTV14: function (param) {
    wx.navigateTo({
      url: 'CCTV-14',
    })
  },  
  goToCCTV15: function (param) {
    wx.navigateTo({
      url: 'CCTV-15',
    })
  },  
  goToZJWS: function (param) {
    wx.navigateTo({
      url: 'ZJWS',
    })
  },  
  goToJSWS: function (param) {
    wx.navigateTo({
      url: 'JSWS',
    })
  },  
  goToDFWS: function (param) {
    wx.navigateTo({
      url: 'DFWS',
    })
  },  
  goToAHWS: function (param) {
    wx.navigateTo({
      url: 'AHWS',
    })
  },  
  goToSZWS: function (param) {
    wx.navigateTo({
      url: 'SZWS',
    })
  },  
  goToHNWS: function (param) {
    wx.navigateTo({
      url: 'HNWS',
    })
  },
  goToSurprise: function (param) {
    wx.navigateTo({
      url: '../Myself/Surprise',
    })
  },
})