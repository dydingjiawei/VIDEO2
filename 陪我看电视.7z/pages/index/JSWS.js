Page({
  data: {
    select: false,
    pingdao: '切换播放源',
    url: 'http://huaweicdn.hb.chinamobile.com/PLTV/88888888/224/3221225819/index.m3u8'
  },

  onLoad: function (options) {
  },
  bindShowMsg() {
    this.setData({
      select: !this.data.select
    })
    this.setData({
      channel: !this.data.select
    })
  },
  mySelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      url: name,
      select: false
    })
    var channel = e.currentTarget.dataset.channel
    this.setData({
      pingdao: channel
    })
  },

  onReady: function (res) {
    this.videoContext = wx.createVideoContext('myVideo')
    this.videoContext.play(true)
  },

  bindInputBlur: function (e) {
    this.inputValue = e.detail.value
  },
  bindSendDanmu: function () {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
    })
  },
  bindPlay: function () {
    this.videoContext.play()
  },
  bindPause: function () {
    this.videoContext.pause()
  },
  videoErrorCallback: function (e) {
    console.log('视频错误信息:')
    console.log(e.detail.errMsg)
  },

})